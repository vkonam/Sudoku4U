﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Resources

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("Sudoku4U")> 
<Assembly: AssemblyDescription("Sudoku For You")> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyCompany("Ajantha LLC")> 
<Assembly: AssemblyProduct("Sudoku4U")> 
<Assembly: AssemblyCopyright("Vijayashankar Konam")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")> 

' Setting ComVisible to false makes the types in this assembly not visible 
' to COM components.  If you need to access a type in this assembly from 
' COM, set the ComVisible attribute to true on that type.
<assembly: ComVisible(false)>

' The following GUID is for the ID of the typelib if this project is exposed to COM
<assembly: Guid("318e275c-b908-4e36-93b6-5059be62e7df")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Revision and Build Numbers 
' by using the '*' as shown below:
<Assembly: AssemblyVersion("1.1.0")> 
<Assembly: AssemblyFileVersion("1.1.0")> 
<assembly: NeutralResourcesLanguageAttribute("en-US")>
