﻿Public Class SavedSudoku
    Public strSudoku As String
    'Public strSudokuSeeds As String
    Public elapsedTime As New TimeSpan
    Public mistakesCount As New Integer
    Public strSudokuSolution As String
    Public strSudokuSeeds As String
    Public Sub New()
        strSudoku = ""
        strSudokuSeeds = ""
        strSudokuSolution = ""
        mistakesCount = 0
    End Sub

End Class
